string = 'python prog language'

index = 0

while index < len(string):
    if string[index] == 'a':
        break
    print(string[index], end="")
