a = (2, 4, 6, 8)
b = (3, 1, 5, 7)

c = a.join(b)

print(c)
