string = "Python Programming"

for i in string:
    if i.lower() in "pho":
        pass
    print(i, end='')
