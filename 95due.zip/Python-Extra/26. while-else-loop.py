counter = 0

while counter < 5:
    print("Hello world!")
