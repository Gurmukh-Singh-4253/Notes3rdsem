x = 3     # int
y = 2.54  # flaut

x = float(x)  # explicit conversion to float
y = int(y)    # explicit conversion to int

print(x, y)

y = complex(y)  # Explicit conversion from int to complex
