str1 = "Hello"
str2 = "World"

concatstr = str1 + str2

print("str1: ", str1)
print("str2: ", str2)
print("Concatenated string: ", concatstr)
