x = "ahoj"
y = x

print('Result of x is y when both are equal', x is y)

array = [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

notsq = 33

print("Result of element in array when not present:", notsq in array)
print("Result of element not in array when not present:", notsq not in array)
