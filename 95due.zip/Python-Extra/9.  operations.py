x = 1024
y = 511

# Left shift be like
print(x)
x << 2
print(x)


# Right shift be like
x >> 2
print(x)


# XOR operation be like
print("x is :", x)
print("y is :", y)
xor = x ^ y
print("xor is :", xor)


# Bitwise AND operation be like
print("x is :", x)
print("y is :", y)
ansand = x & y
print("and is :", ansand)


# Bitwise OR operation be like
print("x is :", x)
print("y is :", y)
ansor = x | y
print("OR is :", ansor)
