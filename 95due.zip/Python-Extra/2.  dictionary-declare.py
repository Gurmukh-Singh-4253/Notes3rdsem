dictitem = {
        1: "one",
        2: "two",
        3: "three",
        4: "four",
        5: "five"
        }

for i in dictitem.keys():
    print(i, dictitem[i])
