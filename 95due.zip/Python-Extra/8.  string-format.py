string = "Hello there, This is {name}"

print(string.format(name="Vansh Sood"))
