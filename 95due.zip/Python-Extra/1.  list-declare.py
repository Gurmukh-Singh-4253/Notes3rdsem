listitem = [1, 2, 3, 4, 5]

for i in listitem:
    print(i, end='\t')
