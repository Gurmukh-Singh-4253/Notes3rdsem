x = 1 + 4j

print(type(x))
