print("Type of True: ", type(True))
print("Type of False: ", type(False))
