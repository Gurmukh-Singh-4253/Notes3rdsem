age = int(input("Enter the age of the candidate:"))

if age >= 18:
    print("The candidate is eligible to vote.")
else:
    print("The candidate is not eligible to vote.")
