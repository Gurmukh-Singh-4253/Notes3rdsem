x = int(input("Enter a number: "))

if x % 2 == 0:
    print(f"{x} is an even number")
else:
    print(f"{x} is an odd number")
