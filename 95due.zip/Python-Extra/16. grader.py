marks = int(input("Enter the marks of the student:"))

if marks > 90:
    grade = 'O'
elif marks > 85:
    grade = 'A+'
elif marks > 80:
    grade = 'A'
elif marks > 75:
    grade = 'B+'
elif marks > 70:
    grade = 'B'
elif marks > 65:
    grade = 'C+'
elif marks > 60:
    grade = 'C'
elif marks > 55:
    grade = 'D+'
elif marks > 50:
    grade = 'D'
elif marks > 45:
    grade = 'E+'
elif marks > 4O:
    grade = 'E'
else:
    grade = 'F'
